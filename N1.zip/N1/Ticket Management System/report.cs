﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Management_System
{
    public partial class report : Form
    {
        public report()
        {
            InitializeComponent();
        }

        private void dataGridView_weeklyReport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void weeklyReportChart_Click(object sender, EventArgs e)
        {

        }

        private void report_Load(object sender, EventArgs e)
        {
            dataGridView_dailyReport.AllowUserToAddRows = false;
            dataGridView_weeklyReport.AllowUserToAddRows = false;   
        }

        private void daily_report()
        {
            Person obj = new Person();
            List<Person> list = obj.List();
            List<Person> personList = new List<Person>();
            DateTime startdate = dateTimePickerStartDate.Value.Subtract(TimeSpan.FromDays(1));
            DateTime enddate = dateTimePickerEndDate.Value;
            for (var i = 0; i < list.Count; i++)
            {
                if (Comparer<DateTime>.Default.Compare(list[i].VisitDate, startdate) >= 0 &&
            Comparer<DateTime>.Default.Compare(list[i].VisitDate, enddate) <= 0)
                {
                    personList.Add(list[i]);
                }
            }

            if (personList != null)
            {
                var result = personList
                    .GroupBy(l => l.Category)
                    .Select(cl => new
                    {
                        Category = cl.First().Category,
                        // totalPeople = cl.Count().ToString(),
                        Total_People = cl.Sum(c => int.Parse(c.TotalPeople)).ToString(),
                    }).ToList();
                DataTable dt = Utilities.ConvertToDataTable(result);
                dataGridView_dailyReport.DataSource = dt;
            }
        }

        private void weekly_report()
        {
            Person obj = new Person();
            List<Person> list = obj.List();
            List<Person> personList = new List<Person>();
            DateTime startdate = dateTimePicker_startDate.Value.Subtract(TimeSpan.FromDays(1));
            DateTime endDate = dateTimePicker_endDate.Value;
            for (var i = 0; i < list.Count; i++)
            {
                if (Comparer<DateTime>.Default.Compare(list[i].VisitDate, startdate) >= 0 &&
                Comparer<DateTime>.Default.Compare(list[i].VisitDate, endDate) <= 0)
                {
                    personList.Add(list[i]);
                }
            }

            if (personList != null)
            {
                var result = personList
                    .GroupBy(l => l.VisitDay)
                    .Select(cl => new
                    {
                        Day = cl.First().VisitDay,
                        Total_People = cl.Sum(c => int.Parse(c.TotalPeople)).ToString(),
                        Total_Income = cl.Sum(c => (int.Parse(c.TotalPeople) * int.Parse(c.Rate))).ToString(),
                    }).ToList();
                DataTable dt = Utilities.ConvertToDataTable(result);
                dataGridView_weeklyReport.DataSource = dt;
            }
        }

        private void dateTimePickerStartDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime startdate = dateTimePickerStartDate.Value;
            dateTimePickerEndDate.Value = startdate.AddDays(0);
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            daily_report();
        }

        private void dateTimePicker_startDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime startdate = dateTimePicker_startDate.Value;
            dateTimePicker_endDate.Value = startdate.AddDays(7);
        }

        private void dateTimePicker_endDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime enddate = dateTimePicker_endDate.Value;
            dateTimePicker_startDate.Value = enddate.Subtract(TimeSpan.FromDays(7));
        }

        private void btnWeeklyReport_Click(object sender, EventArgs e)
        {
            weekly_report();
        }

        private void dateTimePickerEndDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime enddate = dateTimePickerEndDate.Value;
            dateTimePickerStartDate.Value = enddate.Subtract(TimeSpan.FromDays(0));
        }
    }
}

﻿
namespace Ticket_Management_System
{
    partial class report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_dailyReport = new System.Windows.Forms.DataGridView();
            this.dateTimePickerStartDate = new System.Windows.Forms.DateTimePicker();
            this.btnViewReport1 = new System.Windows.Forms.Button();
            this.dataGridView_weeklyReport = new System.Windows.Forms.DataGridView();
            this.dateTimePicker_endDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_startDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnViewReport2 = new System.Windows.Forms.Button();
            this.lblSeparator1 = new System.Windows.Forms.Label();
            this.lblSeparator2 = new System.Windows.Forms.Label();
            this.dateTimePickerEndDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_dailyReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_weeklyReport)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_dailyReport
            // 
            this.dataGridView_dailyReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_dailyReport.Location = new System.Drawing.Point(39, 162);
            this.dataGridView_dailyReport.Name = "dataGridView_dailyReport";
            this.dataGridView_dailyReport.RowHeadersWidth = 62;
            this.dataGridView_dailyReport.RowTemplate.Height = 28;
            this.dataGridView_dailyReport.Size = new System.Drawing.Size(703, 254);
            this.dataGridView_dailyReport.TabIndex = 40;
            // 
            // dateTimePickerStartDate
            // 
            this.dateTimePickerStartDate.CalendarForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePickerStartDate.Location = new System.Drawing.Point(39, 106);
            this.dateTimePickerStartDate.Name = "dateTimePickerStartDate";
            this.dateTimePickerStartDate.Size = new System.Drawing.Size(276, 26);
            this.dateTimePickerStartDate.TabIndex = 43;
            this.dateTimePickerStartDate.ValueChanged += new System.EventHandler(this.dateTimePickerStartDate_ValueChanged);
            // 
            // btnViewReport1
            // 
            this.btnViewReport1.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnViewReport1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewReport1.ForeColor = System.Drawing.Color.White;
            this.btnViewReport1.Location = new System.Drawing.Point(39, 440);
            this.btnViewReport1.Name = "btnViewReport1";
            this.btnViewReport1.Size = new System.Drawing.Size(149, 50);
            this.btnViewReport1.TabIndex = 45;
            this.btnViewReport1.Text = "View Report";
            this.btnViewReport1.UseVisualStyleBackColor = false;
            this.btnViewReport1.Click += new System.EventHandler(this.btnShowDetails_Click);
            // 
            // dataGridView_weeklyReport
            // 
            this.dataGridView_weeklyReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_weeklyReport.Location = new System.Drawing.Point(39, 606);
            this.dataGridView_weeklyReport.Name = "dataGridView_weeklyReport";
            this.dataGridView_weeklyReport.RowHeadersWidth = 62;
            this.dataGridView_weeklyReport.RowTemplate.Height = 28;
            this.dataGridView_weeklyReport.Size = new System.Drawing.Size(703, 254);
            this.dataGridView_weeklyReport.TabIndex = 46;
            // 
            // dateTimePicker_endDate
            // 
            this.dateTimePicker_endDate.CalendarForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePicker_endDate.Location = new System.Drawing.Point(475, 542);
            this.dateTimePicker_endDate.Name = "dateTimePicker_endDate";
            this.dateTimePicker_endDate.Size = new System.Drawing.Size(267, 26);
            this.dateTimePicker_endDate.TabIndex = 49;
            this.dateTimePicker_endDate.ValueChanged += new System.EventHandler(this.dateTimePicker_endDate_ValueChanged);
            // 
            // dateTimePicker_startDate
            // 
            this.dateTimePicker_startDate.CalendarForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePicker_startDate.Location = new System.Drawing.Point(39, 542);
            this.dateTimePicker_startDate.Name = "dateTimePicker_startDate";
            this.dateTimePicker_startDate.Size = new System.Drawing.Size(276, 26);
            this.dateTimePicker_startDate.TabIndex = 48;
            this.dateTimePicker_startDate.ValueChanged += new System.EventHandler(this.dateTimePicker_startDate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(370, 548);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "to";
            // 
            // btnViewReport2
            // 
            this.btnViewReport2.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnViewReport2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewReport2.ForeColor = System.Drawing.Color.White;
            this.btnViewReport2.Location = new System.Drawing.Point(39, 891);
            this.btnViewReport2.Name = "btnViewReport2";
            this.btnViewReport2.Size = new System.Drawing.Size(149, 50);
            this.btnViewReport2.TabIndex = 50;
            this.btnViewReport2.Text = "View Report";
            this.btnViewReport2.UseVisualStyleBackColor = false;
            this.btnViewReport2.Click += new System.EventHandler(this.btnWeeklyReport_Click);
            // 
            // lblSeparator1
            // 
            this.lblSeparator1.AutoSize = true;
            this.lblSeparator1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblSeparator1.Location = new System.Drawing.Point(37, 497);
            this.lblSeparator1.Name = "lblSeparator1";
            this.lblSeparator1.Size = new System.Drawing.Size(702, 20);
            this.lblSeparator1.TabIndex = 51;
            this.lblSeparator1.Text = "_____________________________________________________________________________";
            // 
            // lblSeparator2
            // 
            this.lblSeparator2.AutoSize = true;
            this.lblSeparator2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblSeparator2.Location = new System.Drawing.Point(35, 940);
            this.lblSeparator2.Name = "lblSeparator2";
            this.lblSeparator2.Size = new System.Drawing.Size(702, 20);
            this.lblSeparator2.TabIndex = 52;
            this.lblSeparator2.Text = "_____________________________________________________________________________";
            // 
            // dateTimePickerEndDate
            // 
            this.dateTimePickerEndDate.CalendarForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePickerEndDate.Location = new System.Drawing.Point(466, 106);
            this.dateTimePickerEndDate.Name = "dateTimePickerEndDate";
            this.dateTimePickerEndDate.Size = new System.Drawing.Size(276, 26);
            this.dateTimePickerEndDate.TabIndex = 53;
            this.dateTimePickerEndDate.Visible = false;
            this.dateTimePickerEndDate.ValueChanged += new System.EventHandler(this.dateTimePickerEndDate_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(293, 502);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 25);
            this.label2.TabIndex = 54;
            this.label2.Text = "WEEKLY REPORT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(293, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 25);
            this.label3.TabIndex = 55;
            this.label3.Text = "DAILY REPORT";
            // 
            // report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(826, 945);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePickerEndDate);
            this.Controls.Add(this.lblSeparator2);
            this.Controls.Add(this.lblSeparator1);
            this.Controls.Add(this.btnViewReport2);
            this.Controls.Add(this.dateTimePicker_endDate);
            this.Controls.Add(this.dateTimePicker_startDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView_weeklyReport);
            this.Controls.Add(this.btnViewReport1);
            this.Controls.Add(this.dateTimePickerStartDate);
            this.Controls.Add(this.dataGridView_dailyReport);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "report";
            this.Text = "report";
            this.Load += new System.EventHandler(this.report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_dailyReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_weeklyReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView_dailyReport;
        private System.Windows.Forms.DateTimePicker dateTimePickerStartDate;
        private System.Windows.Forms.Button btnViewReport1;
        private System.Windows.Forms.DataGridView dataGridView_weeklyReport;
        private System.Windows.Forms.DateTimePicker dateTimePicker_endDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_startDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnViewReport2;
        private System.Windows.Forms.Label lblSeparator1;
        private System.Windows.Forms.Label lblSeparator2;
        private System.Windows.Forms.DateTimePicker dateTimePickerEndDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string username = "admin";
        string password = "12345";

        // Clear login details
        private void clearLoginForm()
        {
            cbUserType.SelectedItem = "Admin";
            tbUsername.Text = "";
            tbPassword.Text = "";
        }

        private void lbFP_Click(object sender, EventArgs e)
        {

        }

        private void lbLogin_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (tbUsername.Text.Trim() == "")
            {
                MessageBox.Show("Please enter your username.");
                tbUsername.Focus();
            }
            else if (tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Please enter your password.");
                tbPassword.Focus();
            }
            else
            {
                if (cbUserType.SelectedItem.ToString() == "Admin")
                {
                    // Opens admin dashboard if login credentials are correct, otherwise shows error message in a MessageBox
                    if (tbUsername.Text == username && tbPassword.Text == password)
                    {
                        Dashboard db = new Dashboard();
                        db.Show(); // opens admin dashboard
                        this.Hide();
                    }
                    else if (tbUsername.Text != "admin")
                    {
                        MessageBox.Show("The username you entered is incorrect.");
                        tbUsername.Focus();
                    }
                    else if (tbPassword.Text != "12345")
                    {
                        MessageBox.Show("The password you entered is incorrect.");
                        tbPassword.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please make sure you have selected the correct User Type.");
                    cbUserType.Focus();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearLoginForm();
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked == true)
            {
                tbPassword.UseSystemPasswordChar = false;
            }
            else
            {
                tbPassword.UseSystemPasswordChar = true;
            }
        }
    }
}

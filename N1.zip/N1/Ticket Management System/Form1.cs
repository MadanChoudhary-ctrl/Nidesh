﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Clear login details
        private void clearLoginForm()
        {
            tbUsername.Text = "";
            tbPassword.Text = "";
        }

        private void lbFP_Click(object sender, EventArgs e)
        {

        }

        private void lbLogin_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (tbUsername.Text.Trim() == "")
            {
                MessageBox.Show("Please enter your username.");
                tbUsername.Focus();
            }
            else if (tbPassword.Text.Trim() == "")
            {
                MessageBox.Show("Please enter your password.");
                tbPassword.Focus();
            }
            else
            {
                // opens dashboard form if singin details are correct
                // shows error message if signin details are incorrect
                if (tbUsername.Text == "username@123" && tbPassword.Text == "password@123")
                {
                    Dashboard db = new Dashboard();
                    db.Show(); // opens dashboard form
                    this.Hide(); // hides signin form
                }
                else if (tbUsername.Text != "username@123")
                {
                    MessageBox.Show("Incorrect username!!!");
                    tbUsername.Focus();
                }
                else if (tbPassword.Text != "password@123")
                {
                    MessageBox.Show("Incorrect password!!!");
                    tbPassword.Focus();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lbUsername_Click(object sender, EventArgs e)
        {

        }

        private void lbPassword_Click(object sender, EventArgs e)
        {

        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

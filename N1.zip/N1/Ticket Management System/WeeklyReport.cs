﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Management_System
{
    public partial class WeeklyReport : Form
    {
        public WeeklyReport()
        {
            InitializeComponent();
            dateTimePicker_endDate.Value = dateTimePicker_startDate.Value.AddDays(7);
        }

        private void DailyReport_Load(object sender, EventArgs e)
        {
            dataGridView_weeklyReport.AllowUserToAddRows = false;
        }

        private void btnShowChart_Click(object sender, EventArgs e)
        {
            Person obj = new Person();
            List<Person> personList = obj.List();
            weekly_report();
        }

        private void dateTimePicker_startDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime startdate = dateTimePicker_startDate.Value;
            dateTimePicker_endDate.Value = startdate.AddDays(7);
        }

        private void dateTimePicker_endDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime enddate = dateTimePicker_endDate.Value;
            dateTimePicker_startDate.Value = enddate.Subtract(TimeSpan.FromDays(7));
        }

        private void weekly_report()
        {
            Person obj = new Person();
            List<Person> list = obj.List();
            List<Person> personList = new List<Person>();
            DateTime startdate = dateTimePicker_startDate.Value.Subtract(TimeSpan.FromDays(1));
            DateTime endDate = dateTimePicker_endDate.Value;
            for (var i = 0; i < list.Count; i++)
            {
                if (Comparer<DateTime>.Default.Compare(list[i].VisitDate, startdate) >= 0 &&
                Comparer<DateTime>.Default.Compare(list[i].VisitDate, endDate) <= 0)
                {
                    personList.Add(list[i]);
                }
            }

            if (personList != null)
            {
                var result = personList
                    .GroupBy(l => l.VisitDay)
                    .Select(cl => new
                    {
                        Day = cl.First().VisitDay,
                        Total_People = cl.Sum(c => int.Parse(c.TotalPeople)).ToString(),
                        Total_Income = cl.Sum(c => (int.Parse(c.TotalPeople) * int.Parse(c.Rate))).ToString(),
                    }).ToList();
                DataTable dt = Utilities.ConvertToDataTable(result);
                dataGridView_weeklyReport.DataSource = dt;
                chart1.DataSource = dt;
                chart1.Series["Series1"].XValueMember = "Day";
                chart1.Series["Series1"].YValueMembers = "Total_People";
                this.chart1.Titles.Remove(this.chart1.Titles.FirstOrDefault());
                this.chart1.Titles.Add("Total number of visitors");
                chart1.Series["Series1"].IsValueShownAsLabel = false;

                chart2.DataSource = dt;
                chart2.Series["Series1"].XValueMember = "Day";
                chart2.Series["Series1"].YValueMembers = "Total_Income";
                this.chart2.Titles.Remove(this.chart2.Titles.FirstOrDefault());
                this.chart2.Titles.Add("Total income of the week");
                chart1.Series["Series1"].IsValueShownAsLabel = false;
            }
        }
    }
}

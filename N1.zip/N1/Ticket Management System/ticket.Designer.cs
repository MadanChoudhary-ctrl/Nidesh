﻿
namespace Ticket_Management_System
{
    partial class ticket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.lbCategory = new System.Windows.Forms.Label();
            this.tbPhone = new System.Windows.Forms.TextBox();
            this.lbPhone = new System.Windows.Forms.Label();
            this.tbAddress = new System.Windows.Forms.TextBox();
            this.lbAddress = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.lbName = new System.Windows.Forms.Label();
            this.lbRate = new System.Windows.Forms.Label();
            this.tbTotalTime = new System.Windows.Forms.TextBox();
            this.tbOutTime = new System.Windows.Forms.TextBox();
            this.lbOutTime = new System.Windows.Forms.Label();
            this.tbInTime = new System.Windows.Forms.TextBox();
            this.lbInTime = new System.Windows.Forms.Label();
            this.lbTotalPeople = new System.Windows.Forms.Label();
            this.tbTotalPeople = new System.Windows.Forms.TextBox();
            this.tbRate = new System.Windows.Forms.TextBox();
            this.lbDate = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblTicketHeader = new System.Windows.Forms.Label();
            this.lblDay = new System.Windows.Forms.Label();
            this.lblCurrentDay = new System.Windows.Forms.Label();
            this.lbTotalTime = new System.Windows.Forms.Label();
            this.dataGridViewCustomerDetails = new System.Windows.Forms.DataGridView();
            this.btnExportToCSV = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnSortByDate = new System.Windows.Forms.Button();
            this.btnImport2 = new System.Windows.Forms.Button();
            this.btnImport1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblWeekdayRate = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomerDetails)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // cbCategory
            // 
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Items.AddRange(new object[] {
            "Child",
            "Adult",
            "Group of 5",
            "Group of 10",
            "Group of 15",
            "Group of 20"});
            this.cbCategory.Location = new System.Drawing.Point(80, 539);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(251, 28);
            this.cbCategory.TabIndex = 22;
            this.cbCategory.Text = "Child";
            // 
            // lbCategory
            // 
            this.lbCategory.AutoSize = true;
            this.lbCategory.ForeColor = System.Drawing.Color.Black;
            this.lbCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbCategory.Location = new System.Drawing.Point(76, 508);
            this.lbCategory.Name = "lbCategory";
            this.lbCategory.Size = new System.Drawing.Size(99, 20);
            this.lbCategory.TabIndex = 21;
            this.lbCategory.Text = "CATEGORY";
            // 
            // tbPhone
            // 
            this.tbPhone.Location = new System.Drawing.Point(80, 454);
            this.tbPhone.Name = "tbPhone";
            this.tbPhone.Size = new System.Drawing.Size(251, 26);
            this.tbPhone.TabIndex = 20;
            this.tbPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPhone_KeyPress);
            // 
            // lbPhone
            // 
            this.lbPhone.AutoSize = true;
            this.lbPhone.ForeColor = System.Drawing.Color.Black;
            this.lbPhone.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbPhone.Location = new System.Drawing.Point(76, 421);
            this.lbPhone.Name = "lbPhone";
            this.lbPhone.Size = new System.Drawing.Size(65, 20);
            this.lbPhone.TabIndex = 19;
            this.lbPhone.Text = "PHONE";
            // 
            // tbAddress
            // 
            this.tbAddress.Location = new System.Drawing.Point(80, 284);
            this.tbAddress.Multiline = true;
            this.tbAddress.Name = "tbAddress";
            this.tbAddress.Size = new System.Drawing.Size(251, 109);
            this.tbAddress.TabIndex = 18;
            // 
            // lbAddress
            // 
            this.lbAddress.AutoSize = true;
            this.lbAddress.ForeColor = System.Drawing.Color.Black;
            this.lbAddress.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbAddress.Location = new System.Drawing.Point(76, 251);
            this.lbAddress.Name = "lbAddress";
            this.lbAddress.Size = new System.Drawing.Size(89, 20);
            this.lbAddress.TabIndex = 17;
            this.lbAddress.Text = "ADDRESS";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(80, 204);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(251, 26);
            this.tbName.TabIndex = 16;
            this.tbName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbName_KeyPress);
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.ForeColor = System.Drawing.Color.Black;
            this.lbName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbName.Location = new System.Drawing.Point(76, 171);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(55, 20);
            this.lbName.TabIndex = 15;
            this.lbName.Text = "NAME";
            // 
            // lbRate
            // 
            this.lbRate.AutoSize = true;
            this.lbRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRate.ForeColor = System.Drawing.Color.Black;
            this.lbRate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbRate.Location = new System.Drawing.Point(454, 508);
            this.lbRate.Name = "lbRate";
            this.lbRate.Size = new System.Drawing.Size(52, 20);
            this.lbRate.TabIndex = 31;
            this.lbRate.Text = "RATE";
            this.lbRate.Click += new System.EventHandler(this.lbRate_Click);
            // 
            // tbTotalTime
            // 
            this.tbTotalTime.Location = new System.Drawing.Point(458, 454);
            this.tbTotalTime.Name = "tbTotalTime";
            this.tbTotalTime.Size = new System.Drawing.Size(251, 26);
            this.tbTotalTime.TabIndex = 30;
            // 
            // tbOutTime
            // 
            this.tbOutTime.Location = new System.Drawing.Point(458, 371);
            this.tbOutTime.Name = "tbOutTime";
            this.tbOutTime.Size = new System.Drawing.Size(251, 26);
            this.tbOutTime.TabIndex = 28;
            this.tbOutTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOutTime_KeyPress);
            // 
            // lbOutTime
            // 
            this.lbOutTime.AutoSize = true;
            this.lbOutTime.ForeColor = System.Drawing.Color.Black;
            this.lbOutTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbOutTime.Location = new System.Drawing.Point(454, 338);
            this.lbOutTime.Name = "lbOutTime";
            this.lbOutTime.Size = new System.Drawing.Size(85, 20);
            this.lbOutTime.TabIndex = 27;
            this.lbOutTime.Text = "OUT-TIME";
            // 
            // tbInTime
            // 
            this.tbInTime.Location = new System.Drawing.Point(458, 291);
            this.tbInTime.Name = "tbInTime";
            this.tbInTime.Size = new System.Drawing.Size(251, 26);
            this.tbInTime.TabIndex = 26;
            this.tbInTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbInTime_KeyPress);
            // 
            // lbInTime
            // 
            this.lbInTime.AutoSize = true;
            this.lbInTime.ForeColor = System.Drawing.Color.Black;
            this.lbInTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbInTime.Location = new System.Drawing.Point(454, 258);
            this.lbInTime.Name = "lbInTime";
            this.lbInTime.Size = new System.Drawing.Size(68, 20);
            this.lbInTime.TabIndex = 25;
            this.lbInTime.Text = "IN-TIME";
            // 
            // lbTotalPeople
            // 
            this.lbTotalPeople.AutoSize = true;
            this.lbTotalPeople.ForeColor = System.Drawing.Color.Black;
            this.lbTotalPeople.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbTotalPeople.Location = new System.Drawing.Point(454, 176);
            this.lbTotalPeople.Name = "lbTotalPeople";
            this.lbTotalPeople.Size = new System.Drawing.Size(126, 20);
            this.lbTotalPeople.TabIndex = 23;
            this.lbTotalPeople.Text = "TOTAL PEOPLE";
            // 
            // tbTotalPeople
            // 
            this.tbTotalPeople.Location = new System.Drawing.Point(458, 209);
            this.tbTotalPeople.Name = "tbTotalPeople";
            this.tbTotalPeople.Size = new System.Drawing.Size(251, 26);
            this.tbTotalPeople.TabIndex = 24;
            this.tbTotalPeople.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTotalPeople_KeyPress);
            // 
            // tbRate
            // 
            this.tbRate.Location = new System.Drawing.Point(458, 541);
            this.tbRate.Name = "tbRate";
            this.tbRate.Size = new System.Drawing.Size(251, 26);
            this.tbRate.TabIndex = 33;
            // 
            // lbDate
            // 
            this.lbDate.AutoSize = true;
            this.lbDate.ForeColor = System.Drawing.Color.Black;
            this.lbDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbDate.Location = new System.Drawing.Point(76, 122);
            this.lbDate.Name = "lbDate";
            this.lbDate.Size = new System.Drawing.Size(48, 20);
            this.lbDate.TabIndex = 34;
            this.lbDate.Text = "Date:";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSave.Location = new System.Drawing.Point(80, 603);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(157, 47);
            this.btnSave.TabIndex = 36;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblTicketHeader
            // 
            this.lblTicketHeader.AutoSize = true;
            this.lblTicketHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblTicketHeader.ForeColor = System.Drawing.Color.Black;
            this.lblTicketHeader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTicketHeader.Location = new System.Drawing.Point(241, 25);
            this.lblTicketHeader.Name = "lblTicketHeader";
            this.lblTicketHeader.Size = new System.Drawing.Size(265, 25);
            this.lblTicketHeader.TabIndex = 38;
            this.lblTicketHeader.Text = "ENTER TICKET DETAILS";
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.ForeColor = System.Drawing.Color.Black;
            this.lblDay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDay.Location = new System.Drawing.Point(461, 128);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(41, 20);
            this.lblDay.TabIndex = 39;
            this.lblDay.Text = "Day:";
            // 
            // lblCurrentDay
            // 
            this.lblCurrentDay.AutoSize = true;
            this.lblCurrentDay.ForeColor = System.Drawing.Color.Black;
            this.lblCurrentDay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCurrentDay.Location = new System.Drawing.Point(527, 128);
            this.lblCurrentDay.Name = "lblCurrentDay";
            this.lblCurrentDay.Size = new System.Drawing.Size(120, 20);
            this.lblCurrentDay.TabIndex = 41;
            this.lblCurrentDay.Text = "day of the week";
            this.lblCurrentDay.Click += new System.EventHandler(this.lblCurrentDay_Click);
            // 
            // lbTotalTime
            // 
            this.lbTotalTime.AutoSize = true;
            this.lbTotalTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalTime.ForeColor = System.Drawing.Color.Black;
            this.lbTotalTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbTotalTime.Location = new System.Drawing.Point(454, 421);
            this.lbTotalTime.Name = "lbTotalTime";
            this.lbTotalTime.Size = new System.Drawing.Size(101, 20);
            this.lbTotalTime.TabIndex = 29;
            this.lbTotalTime.Text = "TOTAL TIME";
            this.lbTotalTime.Click += new System.EventHandler(this.lbTotalTime_Click);
            // 
            // dataGridViewCustomerDetails
            // 
            this.dataGridViewCustomerDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCustomerDetails.Location = new System.Drawing.Point(12, 759);
            this.dataGridViewCustomerDetails.Name = "dataGridViewCustomerDetails";
            this.dataGridViewCustomerDetails.RowHeadersWidth = 62;
            this.dataGridViewCustomerDetails.RowTemplate.Height = 28;
            this.dataGridViewCustomerDetails.Size = new System.Drawing.Size(758, 335);
            this.dataGridViewCustomerDetails.TabIndex = 42;
            this.dataGridViewCustomerDetails.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridViewCustomerDetails_RowsPostPaint);
            // 
            // btnExportToCSV
            // 
            this.btnExportToCSV.BackColor = System.Drawing.Color.Black;
            this.btnExportToCSV.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.btnExportToCSV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportToCSV.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.btnExportToCSV.ForeColor = System.Drawing.Color.White;
            this.btnExportToCSV.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnExportToCSV.Location = new System.Drawing.Point(504, 603);
            this.btnExportToCSV.Name = "btnExportToCSV";
            this.btnExportToCSV.Size = new System.Drawing.Size(205, 47);
            this.btnExportToCSV.TabIndex = 43;
            this.btnExportToCSV.Text = "EXPORT TO CSV";
            this.btnExportToCSV.UseVisualStyleBackColor = false;
            this.btnExportToCSV.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(316, 708);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 25);
            this.label1.TabIndex = 44;
            this.label1.Text = "Customer Details";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(131, 122);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker1.TabIndex = 45;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btnSortByDate
            // 
            this.btnSortByDate.BackColor = System.Drawing.Color.Black;
            this.btnSortByDate.FlatAppearance.BorderColor = System.Drawing.Color.Wheat;
            this.btnSortByDate.FlatAppearance.BorderSize = 0;
            this.btnSortByDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSortByDate.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortByDate.ForeColor = System.Drawing.Color.Beige;
            this.btnSortByDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSortByDate.Location = new System.Drawing.Point(80, 698);
            this.btnSortByDate.Name = "btnSortByDate";
            this.btnSortByDate.Size = new System.Drawing.Size(157, 47);
            this.btnSortByDate.TabIndex = 46;
            this.btnSortByDate.Text = "Sort By Date";
            this.btnSortByDate.UseVisualStyleBackColor = false;
            this.btnSortByDate.Click += new System.EventHandler(this.btnSortByDate_Click);
            // 
            // btnImport2
            // 
            this.btnImport2.BackColor = System.Drawing.Color.Crimson;
            this.btnImport2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImport2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport2.ForeColor = System.Drawing.Color.White;
            this.btnImport2.Location = new System.Drawing.Point(1378, 603);
            this.btnImport2.Name = "btnImport2";
            this.btnImport2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.btnImport2.Size = new System.Drawing.Size(120, 38);
            this.btnImport2.TabIndex = 52;
            this.btnImport2.Text = "Import";
            this.btnImport2.UseVisualStyleBackColor = false;
            this.btnImport2.Click += new System.EventHandler(this.btnUpdate2_Click);
            // 
            // btnImport1
            // 
            this.btnImport1.BackColor = System.Drawing.Color.Crimson;
            this.btnImport1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImport1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport1.ForeColor = System.Drawing.Color.White;
            this.btnImport1.Location = new System.Drawing.Point(1378, 145);
            this.btnImport1.Name = "btnImport1";
            this.btnImport1.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.btnImport1.Size = new System.Drawing.Size(120, 38);
            this.btnImport1.TabIndex = 51;
            this.btnImport1.Text = "Import";
            this.btnImport1.UseVisualStyleBackColor = false;
            this.btnImport1.Click += new System.EventHandler(this.btnUpdate1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(975, 613);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 20);
            this.label2.TabIndex = 50;
            this.label2.Text = "Ticket Rate For Holidays";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Location = new System.Drawing.Point(793, 196);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(717, 371);
            this.panel4.TabIndex = 49;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 14);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(690, 342);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblWeekdayRate
            // 
            this.lblWeekdayRate.AutoSize = true;
            this.lblWeekdayRate.BackColor = System.Drawing.Color.White;
            this.lblWeekdayRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.lblWeekdayRate.ForeColor = System.Drawing.Color.Black;
            this.lblWeekdayRate.Location = new System.Drawing.Point(975, 153);
            this.lblWeekdayRate.Name = "lblWeekdayRate";
            this.lblWeekdayRate.Size = new System.Drawing.Size(220, 20);
            this.lblWeekdayRate.TabIndex = 47;
            this.lblWeekdayRate.Text = "Ticket Rate For Weekdays";
            this.lblWeekdayRate.Click += new System.EventHandler(this.lblWeekdayRate_Click);
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.dataGridView2);
            this.panel3.Location = new System.Drawing.Point(793, 656);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(717, 371);
            this.panel3.TabIndex = 48;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(15, 14);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(690, 342);
            this.dataGridView2.TabIndex = 3;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // ticket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1557, 1106);
            this.Controls.Add(this.btnImport2);
            this.Controls.Add(this.btnImport1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lblWeekdayRate);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnSortByDate);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExportToCSV);
            this.Controls.Add(this.dataGridViewCustomerDetails);
            this.Controls.Add(this.lblCurrentDay);
            this.Controls.Add(this.lblDay);
            this.Controls.Add(this.lblTicketHeader);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lbDate);
            this.Controls.Add(this.tbRate);
            this.Controls.Add(this.lbRate);
            this.Controls.Add(this.tbTotalTime);
            this.Controls.Add(this.lbTotalTime);
            this.Controls.Add(this.tbOutTime);
            this.Controls.Add(this.lbOutTime);
            this.Controls.Add(this.tbInTime);
            this.Controls.Add(this.lbInTime);
            this.Controls.Add(this.tbTotalPeople);
            this.Controls.Add(this.lbTotalPeople);
            this.Controls.Add(this.cbCategory);
            this.Controls.Add(this.lbCategory);
            this.Controls.Add(this.tbPhone);
            this.Controls.Add(this.lbPhone);
            this.Controls.Add(this.tbAddress);
            this.Controls.Add(this.lbAddress);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.lbName);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ticket";
            this.Text = "ticket";
            this.Load += new System.EventHandler(this.ticket_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomerDetails)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.Label lbCategory;
        private System.Windows.Forms.TextBox tbPhone;
        private System.Windows.Forms.Label lbPhone;
        private System.Windows.Forms.TextBox tbAddress;
        private System.Windows.Forms.Label lbAddress;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Label lbRate;
        private System.Windows.Forms.TextBox tbTotalTime;
        private System.Windows.Forms.TextBox tbOutTime;
        private System.Windows.Forms.Label lbOutTime;
        private System.Windows.Forms.TextBox tbInTime;
        private System.Windows.Forms.Label lbInTime;
        private System.Windows.Forms.Label lbTotalPeople;
        private System.Windows.Forms.TextBox tbTotalPeople;
        private System.Windows.Forms.TextBox tbRate;
        private System.Windows.Forms.Label lbDate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblTicketHeader;
        private System.Windows.Forms.Label lblDay;
        private System.Windows.Forms.Label lblCurrentDay;
        private System.Windows.Forms.Label lbTotalTime;
        private System.Windows.Forms.DataGridView dataGridViewCustomerDetails;
        private System.Windows.Forms.Button btnExportToCSV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnSortByDate;
        private System.Windows.Forms.Button btnImport2;
        private System.Windows.Forms.Button btnImport1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblWeekdayRate;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}
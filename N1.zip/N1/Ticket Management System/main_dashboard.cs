﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ticket_Management_System
{
    public partial class main_dashboard : Form
    {
        public main_dashboard()
        {
            InitializeComponent();
            weekdays_rate_table();
            holidays_rate_table();
        }
        DataTable table = new DataTable();
        private void main_dashboard_Load(object sender, EventArgs e)
        {

        }

        string path1 = "CSV Files\\weekdaysRate.csv";
        string path2 = "CSV Files\\holidaysRate.csv";
        DataTable dt1 = new DataTable();
        DataTable dt2 = new DataTable();
        private void weekdays_rate_table()
        {
            dataGridView1.AllowUserToAddRows = false;
            dt1.Columns.Add("Category", typeof(string));
            dt1.Columns.Add("1Hr", typeof(string));
            dt1.Columns.Add("2Hrs", typeof(string));
            dt1.Columns.Add("3Hrs", typeof(string));
            dt1.Columns.Add("4Hrs", typeof(string));
            dt1.Columns.Add("Whole day", typeof(string));
            dataGridView1.DataSource = dt1;

            string[] lines = File.ReadAllLines(path1);
            string[] values;

            for (int i = 1; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(',');
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }
                dt1.Rows.Add(row);
            }
        }

        private void holidays_rate_table()
        {
            dataGridView2.AllowUserToAddRows = false;
            dt2.Columns.Add("Category", typeof(string));
            dt2.Columns.Add("1Hr", typeof(string));
            dt2.Columns.Add("2Hrs", typeof(string));
            dt2.Columns.Add("3Hrs", typeof(string));
            dt2.Columns.Add("4Hrs", typeof(string));
            dt2.Columns.Add("Whole day", typeof(string));
            dataGridView2.DataSource = dt2;

            string[] lines = File.ReadAllLines(path2);
            string[] values;

            for (int i = 1; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(',');
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }
                dt2.Rows.Add(row);
            }
        }

        public bool updateFile(DataGridView dgv, string file_path)
        {
            File.WriteAllText(file_path, "");
            bool updated = false;
            List<string> lines = new List<string>();
            DataGridViewColumnCollection header = dgv.Columns;
            bool firstDone = false;
            StringBuilder headerLine = new StringBuilder();
            // for header
            foreach (DataGridViewColumn col in header)
            {
                if (!firstDone)
                {
                    headerLine.Append(col.DataPropertyName);
                    firstDone = true;
                }
                else
                {
                    headerLine.Append("," + col.DataPropertyName);
                }
            }
            lines.Add(headerLine.ToString());
            // for data
            foreach (DataGridViewRow row in dgv.Rows)
            {
                StringBuilder dataLine = new StringBuilder();
                firstDone = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (!firstDone)
                    {
                        dataLine.Append(cell.Value);
                        firstDone = true;
                    }
                    else
                    {
                        dataLine.Append("," + cell.Value);
                    }
                }
                lines.Add(dataLine.ToString());
            }
            System.IO.File.WriteAllLines(file_path, lines);
            MessageBox.Show("Updated Successfully");
            return updated;
        }

        private void dataGridView1_rowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
    
        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            updateFile(dataGridView1, path1);
        }

        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            updateFile(dataGridView1, path2);
        }
    }
}

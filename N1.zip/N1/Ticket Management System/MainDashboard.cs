﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ticket_Management_System
{
    public partial class main_dashboard : Form
    {
        public main_dashboard()
        {
            InitializeComponent();
        }
        DataTable table1 = new DataTable();
        DataTable table2 = new DataTable();
        private string filepath1 = "CSV Files\\weekdays_rate.csv";
        private string filepath2 = "CSV Files\\holidays_rate.csv";
        private void main_dashboard_Load(object sender, EventArgs e)
        {
            weekdaysRateTable();
            holidaysRateTable();
        }

        private void weekdaysRateTable()
        {
            dataGridView1.AllowUserToAddRows = false;
            table1.Columns.Add("Category", typeof(string));
            table1.Columns.Add("1Hr", typeof(string));
            table1.Columns.Add("2Hrs", typeof(string));
            table1.Columns.Add("3Hrs", typeof(string));
            table1.Columns.Add("4Hrs", typeof(string));
            table1.Columns.Add("Whole day", typeof(string));
            dataGridView1.DataSource = table1;

            string[] lines = File.ReadAllLines(filepath1);
            string[] values;

            for (int i = 1; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(',');
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }
                table1.Rows.Add(row);
            }
        }

        private void holidaysRateTable()
        {
            dataGridView2.AllowUserToAddRows = false;
            table2.Columns.Add("Category", typeof(string));
            table2.Columns.Add("1Hr", typeof(string));
            table2.Columns.Add("2Hrs", typeof(string));
            table2.Columns.Add("3Hrs", typeof(string));
            table2.Columns.Add("4Hrs", typeof(string));
            table2.Columns.Add("Whole day", typeof(string));
            dataGridView2.DataSource = table2;

            string[] lines = File.ReadAllLines(filepath2);
            string[] values;

            for (int i = 1; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(',');
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }
                table2.Rows.Add(row);
            }
        }

        private void displayRowNumbers(object sender, DataGridViewRowPostPaintEventArgs e) {
            var grid = sender as DataGridView;
            var rowIndex = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIndex, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            updateFile(dataGridView1, filepath1);
        }

        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            updateFile(dataGridView2, filepath2);
        }

        public bool updateFile(DataGridView dgv, string file_path)
        {
            File.WriteAllText(file_path, "");
            bool updated = false;
            List<string> lines = new List<string>();
            DataGridViewColumnCollection header = dgv.Columns;
            bool firstDone = false;
            StringBuilder headerLine = new StringBuilder();
            foreach (DataGridViewColumn col in header)
            {
                if (!firstDone)
                {
                    headerLine.Append(col.DataPropertyName);
                    firstDone = true;
                }
                else
                {
                    headerLine.Append("," + col.DataPropertyName);
                }
            }
            lines.Add(headerLine.ToString());
            // data lines
            foreach (DataGridViewRow row in dgv.Rows)
            {
                StringBuilder dataLine = new StringBuilder();
                firstDone = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (!firstDone)
                    {
                        dataLine.Append(cell.Value);
                        firstDone = true;
                    }
                    else
                    {
                        dataLine.Append("," + cell.Value);
                    }
                }
                lines.Add(dataLine.ToString());
            }
            System.IO.File.WriteAllLines(file_path, lines);
            MessageBox.Show("Updated Successfully");
            return updated;
        }

        private void dataGridView2_rowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            displayRowNumbers(sender, e);
        }

        private void dataGridView1_rowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            displayRowNumbers(sender, e);
        }
    }
}

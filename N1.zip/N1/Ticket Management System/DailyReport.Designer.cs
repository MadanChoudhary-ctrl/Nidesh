﻿
namespace Ticket_Management_System
{
    partial class dailyreport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReportHeader = new System.Windows.Forms.Label();
            this.dataGridView_dailyReport = new System.Windows.Forms.DataGridView();
            this.dateTimePickerStartDate = new System.Windows.Forms.DateTimePicker();
            this.btnShowDetails = new System.Windows.Forms.Button();
            this.lblSeparator1 = new System.Windows.Forms.Label();
            this.lblSeparator2 = new System.Windows.Forms.Label();
            this.dateTimePickerEndDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_dailyReport)).BeginInit();
            this.SuspendLayout();
            // 
            // lblReportHeader
            // 
            this.lblReportHeader.AutoSize = true;
            this.lblReportHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReportHeader.ForeColor = System.Drawing.Color.Black;
            this.lblReportHeader.Location = new System.Drawing.Point(347, 25);
            this.lblReportHeader.Name = "lblReportHeader";
            this.lblReportHeader.Size = new System.Drawing.Size(99, 25);
            this.lblReportHeader.TabIndex = 39;
            this.lblReportHeader.Text = "REPORT";
            // 
            // dataGridView_dailyReport
            // 
            this.dataGridView_dailyReport.AllowUserToResizeColumns = false;
            this.dataGridView_dailyReport.AllowUserToResizeRows = false;
            this.dataGridView_dailyReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_dailyReport.Location = new System.Drawing.Point(39, 175);
            this.dataGridView_dailyReport.Name = "dataGridView_dailyReport";
            this.dataGridView_dailyReport.RowHeadersWidth = 62;
            this.dataGridView_dailyReport.RowTemplate.Height = 28;
            this.dataGridView_dailyReport.Size = new System.Drawing.Size(703, 254);
            this.dataGridView_dailyReport.TabIndex = 40;
            // 
            // dateTimePickerStartDate
            // 
            this.dateTimePickerStartDate.Location = new System.Drawing.Point(39, 119);
            this.dateTimePickerStartDate.Name = "dateTimePickerStartDate";
            this.dateTimePickerStartDate.Size = new System.Drawing.Size(276, 26);
            this.dateTimePickerStartDate.TabIndex = 43;
            this.dateTimePickerStartDate.ValueChanged += new System.EventHandler(this.dateTimePickerStartDate_ValueChanged);
            // 
            // btnShowDetails
            // 
            this.btnShowDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowDetails.Location = new System.Drawing.Point(39, 453);
            this.btnShowDetails.Name = "btnShowDetails";
            this.btnShowDetails.Size = new System.Drawing.Size(149, 50);
            this.btnShowDetails.TabIndex = 45;
            this.btnShowDetails.Text = "Show Details";
            this.btnShowDetails.UseVisualStyleBackColor = true;
            this.btnShowDetails.Click += new System.EventHandler(this.btnShowDetails_Click);
            // 
            // lblSeparator1
            // 
            this.lblSeparator1.AutoSize = true;
            this.lblSeparator1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblSeparator1.Location = new System.Drawing.Point(35, 675);
            this.lblSeparator1.Name = "lblSeparator1";
            this.lblSeparator1.Size = new System.Drawing.Size(702, 20);
            this.lblSeparator1.TabIndex = 51;
            this.lblSeparator1.Text = "_____________________________________________________________________________";
            // 
            // lblSeparator2
            // 
            this.lblSeparator2.AutoSize = true;
            this.lblSeparator2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblSeparator2.Location = new System.Drawing.Point(35, 940);
            this.lblSeparator2.Name = "lblSeparator2";
            this.lblSeparator2.Size = new System.Drawing.Size(702, 20);
            this.lblSeparator2.TabIndex = 52;
            this.lblSeparator2.Text = "_____________________________________________________________________________";
            // 
            // dateTimePickerEndDate
            // 
            this.dateTimePickerEndDate.Location = new System.Drawing.Point(466, 119);
            this.dateTimePickerEndDate.Name = "dateTimePickerEndDate";
            this.dateTimePickerEndDate.Size = new System.Drawing.Size(276, 26);
            this.dateTimePickerEndDate.TabIndex = 53;
            this.dateTimePickerEndDate.Visible = false;
            this.dateTimePickerEndDate.ValueChanged += new System.EventHandler(this.dateTimePickerEndDate_ValueChanged);
            // 
            // dailyreport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 694);
            this.Controls.Add(this.dateTimePickerEndDate);
            this.Controls.Add(this.lblSeparator2);
            this.Controls.Add(this.lblSeparator1);
            this.Controls.Add(this.btnShowDetails);
            this.Controls.Add(this.dateTimePickerStartDate);
            this.Controls.Add(this.dataGridView_dailyReport);
            this.Controls.Add(this.lblReportHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "dailyreport";
            this.Text = "dailyreport";
            this.Load += new System.EventHandler(this.report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_dailyReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblReportHeader;
        private System.Windows.Forms.DataGridView dataGridView_dailyReport;
        private System.Windows.Forms.DateTimePicker dateTimePickerStartDate;
        private System.Windows.Forms.Button btnShowDetails;
        private System.Windows.Forms.Label lblSeparator1;
        private System.Windows.Forms.Label lblSeparator2;
        private System.Windows.Forms.DateTimePicker dateTimePickerEndDate;
    }
}
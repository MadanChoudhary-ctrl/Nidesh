﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Text;

namespace Ticket_Management_System
{
    public partial class ticket : Form
    {
        public ticket()
        {
            InitializeComponent();
            // DayOfWeek day = DateTime.Today.DayOfWeek;
            lblCurrentDay.Text = dateTimePicker1.Value.DayOfWeek.ToString();
            BindGrid();
            Person obj = new Person();
        }

        private bool sortedByDate = false;
        private bool sortedByName = false; 

        private void lblCurrentDate_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = tbName.Text.Trim();
            string address = tbAddress.Text.Trim();
            string phone = tbPhone.Text.Trim();
            string totalPeople = tbTotalPeople.Text.Trim();
            string inTime = tbInTime.Text.Trim();
            string outTime = tbOutTime.Text.Trim();
            string totalTime = tbTotalTime.Text.Trim();
            string rate = tbRate.Text.Trim();
            string category = "";

            if (cbCategory.SelectedItem.ToString() == "Child")
            {
                category = "Child";
            }
            else if (cbCategory.SelectedItem.ToString() == "Adult")
            {
                category = "Adult";
            }
            else if (cbCategory.SelectedItem.ToString() == "Group of 5")
            {
                category = "Group of 5";
            }
            else if (cbCategory.SelectedItem.ToString() == "Group of 10")
            {
                category = "Group of 10";
            }
            else if (cbCategory.SelectedItem.ToString() == "Group of 15")
            {
                category = "Group of 15";
            }
            else if (cbCategory.SelectedItem.ToString() == "Group of 20")
            {
                category = "Group of 20";
            }

            if (name == "")
            {
                MessageBox.Show("Please enter a name");
                tbName.Focus();
            }
            else if (address == "")
            {
                MessageBox.Show("Please enter a address");
                tbAddress.Focus();
            }
            else if (phone == "")
            {
                MessageBox.Show("Please enter a phone number");
                tbPhone.Focus();
            }
            else if (!phone.All(char.IsDigit))
            {
                MessageBox.Show("Please enter a valid phone number");
                tbPhone.Focus();
            }
            else if (phone.Length != 10)
            {
                MessageBox.Show("Your phone number must be 10 digit long");
                tbPhone.Focus();
            }
            else if (totalPeople == "")
            {
                MessageBox.Show("Please enter the total number of people");
                tbTotalPeople.Focus();
            }
            else if (inTime == "")
            {
                MessageBox.Show("Please enter in-time");
                tbInTime.Focus();
            }
            else if (!inTime.All(char.IsDigit))
            {
                MessageBox.Show("The in-time must be a number");
                tbInTime.Focus();
            }
            else if (outTime == "")
            {
                MessageBox.Show("Please enter out-time");
                tbOutTime.Focus();
            }
            else if (!outTime.All(char.IsDigit))
            {
                MessageBox.Show("The out-time must be a number");
                tbOutTime.Focus();
            }
            else if (totalTime == "")
            {
                MessageBox.Show("Please enter the total time");
                tbTotalTime.Focus();
            }
            else if (rate == "")
            {
                MessageBox.Show("Please enter the rate");
                tbRate.Focus();
            }
            else
            {
                Person obj = new Person();
                obj.Name = name;
                obj.Address = address;
                obj.Phone = phone;
                obj.Category = category;
                obj.TotalPeople = totalPeople;
                obj.InTime = inTime;
                obj.OutTime = outTime;
                obj.TotalTime = totalTime;
                obj.Rate = rate;
                obj.VisitDate = dateTimePicker1.Value;
                obj.VisitDay = lblCurrentDay.Text;
                obj.Add(obj);
                BindGrid();
                clear();
                MessageBox.Show("Record added successfully");
            }
        }

        private void lbRate_Click(object sender, EventArgs e)
        {
            string category = cbCategory.SelectedItem.ToString();
            string total_people = tbTotalPeople.Text.Trim();
            string total_time = tbTotalTime.Text.Trim();

            if (total_people != "" && total_time != "")
            {
                int totalPeople = int.Parse(total_people);
                int totalTime = int.Parse(total_time);
                if (category == "Child" && totalPeople < 5)
                {
                    if (totalPeople < 5)

                        if (totalTime == 1)
                        {
                            tbRate.Text = "400";
                        }
                        else if (totalTime == 2)
                        {
                            tbRate.Text = "700";
                        }
                        else if (totalTime == 3)
                        {
                            tbRate.Text = "1050";
                        }
                        else if (totalTime == 4)
                        {
                            tbRate.Text = "1450";
                        }
                        else if (totalTime > 4)
                        {
                            tbRate.Text = "2200";
                        }
                }
                else if (category == "Adult" && totalPeople < 5)
                {
                    if (totalPeople < 5)

                        if (totalTime == 1)
                        {
                            tbRate.Text = "550";
                        }
                        else if (totalTime == 2)
                        {
                            tbRate.Text = "1000";
                        }
                        else if (totalTime == 3)
                        {
                            tbRate.Text = "1500";
                        }
                        else if (totalTime == 4)
                        {
                            tbRate.Text = "2100";
                        }
                        else if (totalTime > 4)
                        {
                            tbRate.Text = "2700";
                        }
                }
                else
                {
                    tbRate.Text = "5000";
                }
            }
            else if (total_people == "")
            {
                MessageBox.Show("Please enter total people");
                tbTotalPeople.Focus();
            }
            else if (total_time == "")
            {
                MessageBox.Show("Please enter total time");
                tbTotalTime.Focus();
            }
        }

        private void lbTotalTime_Click(object sender, EventArgs e)
        {
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }

        public void clear()
        {
            tbName.Text = "";
            tbAddress.Text = "";
            tbPhone.Text = "";
            cbCategory.SelectedItem = "Child";
            tbTotalPeople.Text = "";
            tbInTime.Text = "";
            tbOutTime.Text = "";
            tbTotalTime.Text = "";
            tbRate.Text = "";
        }

        private void BindGrid()
        {
            Person obj = new Person();
            List<Person> personList = obj.List();
            DataTable dt = Utilities.ConvertToDataTable(personList);
            dataGridViewCustomerDetails.DataSource = dt;
        }

        private void tbTotalPeople_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbInTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOutTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            Utilities.Export();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            lblCurrentDay.Text = dateTimePicker1.Value.DayOfWeek.ToString();
        }

        private void ticket_Load(object sender, EventArgs e)
        {
            dataGridViewCustomerDetails.AllowUserToAddRows = false;
        }

        private void BindDataCSV(DataGridView data_view, string file_path)
        {
            DataTable table = new DataTable();
            string[] lines = System.IO.File.ReadAllLines(file_path);
            if (lines.Length > 0)
            {
                // First line to create header
                string firstLine = lines[0];
                string[] headerLabels = firstLine.Split(',');

                foreach (string header in headerLabels)
                {
                    table.Columns.Add(new DataColumn(header));
                }

                // For data
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] data = lines[i].Split(',');
                    DataRow row = table.NewRow();
                    int colIndex = 0;
                    foreach (string header in headerLabels)
                    {
                        row[header] = data[colIndex++];
                    }
                    table.Rows.Add(row);
                }
            }
            if (table.Rows.Count > 0)
            {
                data_view.DataSource = table;
            }
        }

        private void dataGridViewCustomerDetails_RowsPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIndex = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIndex, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }

        private void chkSortByDate_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void sortByDate()
        {
            Person obj = new Person();
            DateTime temp;
            List<Person> personList = obj.List();
            DateTime[] dateArray = new DateTime[personList.Count];
            int[] idArray = new int[personList.Count];
            int temp1;
            for (int i = 0; i < personList.Count; i++)
            {
                var id = personList[i].Id;
                var date = personList[i].VisitDate;
                dateArray[i] = date;
                idArray[i] = id;
            }
            int l = dateArray.Length;
            for (int i = 0; i < l; i++)
            {
                for (int j = 0; j < l - 1; j++)
                {
                    if (dateArray[j].CompareTo(dateArray[j + 1]) > 0)
                    {
                        temp = dateArray[j];
                        dateArray[j] = dateArray[j + 1];
                        dateArray[j + 1] = temp;
                        temp1 = idArray[j];
                        idArray[j] = idArray[j + 1];
                        idArray[j + 1] = temp1;
                    }
                }
            }
            List<Person> StudentList = new List<Person>();
            for (int i = 0; i < idArray.Length; i++)
            {
                for (int j = 0; j < personList.Count; j++)
                {
                    var id = personList[j].Id;
                    if (idArray[i] == id)
                    {
                        StudentList.Add(personList[j]);
                    }
                }
            }
            DataTable dt = Utilities.ConvertToDataTable(StudentList);
            dataGridViewCustomerDetails.DataSource = dt;
            MessageBox.Show("The table data are sorted by date");
        }

        private void btnSortByDate_Click(object sender, EventArgs e)
        {
            if (sortedByDate == false)
            {
                sortByDate();
                sortedByDate = true;
                sortedByName = false;
            }
            else
            {
                MessageBox.Show("The table data are already sorted by date");
            }
        }

        private void btnSortByName_Click(object sender, EventArgs e)
        {
            if (sortedByName == false)
            {
                sortByName();
                sortedByName = true;
                sortedByDate = false;
            }
            else
            {
                MessageBox.Show("The table data are already sorted by name");
            }
        }

        private void sortByName()
        {
            Person obj = new Person();
            String temp;
            int temp1;
            List<Person> personList = obj.List();
            string[] nameArray = new string[personList.Count];
            int[] idArray = new int[personList.Count];
            for (int i = 0; i < personList.Count; i++)
            {
                var id = personList[i].Id;
                var name = personList[i].Name.Split(' ')[0];
                nameArray[i] = name;
                idArray[i] = id;
            }
            int l = nameArray.Length;

            for (int i = 0; i < l; i++)
            {
                for (int j = 0; j < l - 1; j++)
                {
                    if (nameArray[j] != nameArray[j + 1])
                    {
                        if (nameArray[j].CompareTo(nameArray[j + 1]) > 0)
                        {
                            temp = nameArray[j];
                            nameArray[j] = nameArray[j + 1];
                            nameArray[j + 1] = temp;
                            temp1 = idArray[j];
                            idArray[j] = idArray[j + 1];
                            idArray[j + 1] = temp1;
                        }
                    }
                }
            }
            List<Person> visitorList = new List<Person>();
            for (int i = 0; i < idArray.Length; i++)
            {
                for (int j = 0; j < personList.Count; j++)
                {
                    var id = personList[j].Id;
                    if (idArray[i] == id)
                    {
                        visitorList.Add(personList[j]);
                    }
                }
            }
            DataTable dt = Utilities.ConvertToDataTable(visitorList);
            dataGridViewCustomerDetails.DataSource = dt;
            MessageBox.Show("The table data are sorted by name");
        }

        private void lblCurrentDay_Click(object sender, EventArgs e)
        {

        }

        private void lblWeekdayRate_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            string path = "CSV Files\\weekdaysRate.csv";
            BindDataCSV(dataGridView1, path);
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            string path = "CSV Files\\holidaysRate.csv";
            BindDataCSV(dataGridView2, path);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

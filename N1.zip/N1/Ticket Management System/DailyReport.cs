﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Management_System
{
    public partial class dailyreport : Form
    {
        public dailyreport()
        {
            InitializeComponent();
        }

        private void dataGridView_weeklyReport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void weeklyReportChart_Click(object sender, EventArgs e)
        {

        }

        private void report_Load(object sender, EventArgs e)
        {
            dataGridView_dailyReport.AllowUserToAddRows = false;  
        }

        private void daily_report()
        {
            Person obj = new Person();
            List<Person> list = obj.List();
            List<Person> personList = new List<Person>();
            DateTime startdate = dateTimePickerStartDate.Value.Subtract(TimeSpan.FromDays(1));
            DateTime enddate = dateTimePickerEndDate.Value;
            for (var i = 0; i < list.Count; i++)
            {
                if (Comparer<DateTime>.Default.Compare(list[i].VisitDate, startdate) >= 0 &&
            Comparer<DateTime>.Default.Compare(list[i].VisitDate, enddate) <= 0)
                {
                    personList.Add(list[i]);
                }
            }

            if (personList != null)
            {
                var result = personList
                    .GroupBy(l => l.Category)
                    .Select(cl => new
                    {
                        Category = cl.First().Category,
                        // totalPeople = cl.Count().ToString(),
                        Total_People = cl.Sum(c => int.Parse(c.TotalPeople)).ToString(),
                    }).ToList();
                DataTable dt = Utilities.ConvertToDataTable(result);
                dataGridView_dailyReport.DataSource = dt;
            }
        }

        private void dateTimePickerStartDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime startdate = dateTimePickerStartDate.Value;
            dateTimePickerEndDate.Value = startdate.AddDays(0);
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            daily_report();
        }

        private void dateTimePickerEndDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime enddate = dateTimePickerEndDate.Value;
            dateTimePickerStartDate.Value = enddate.Subtract(TimeSpan.FromDays(0));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Ticket_Management_System
{
    class Person
    {
        private readonly string filePath = "visitor.json";
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Category { get; set; }
        public string TotalPeople { get; set; }
        public string InTime { get; set; }
        public string OutTime { get; set; }
        public string TotalTime { get; set; }
        public string Rate { get; set; }
        public DateTime VisitDate { get; set; }
        public string VisitDay { get; set; }

        public void Add(Person info)
        {
            Random r = new Random();
            info.Id = r.Next(1, 1000);
            string data = JsonConvert.SerializeObject(info, Formatting.None);
            Utilities.WriteToTextFile(filePath, data);
        }

        public List<Person> List()
        {
            string d = Utilities.ReadFromTextFile(filePath);
            if (d != null)
            {
                List<Person> list = JsonConvert.DeserializeObject<List<Person>>(d);
                return list;
            }
            return null;
        }
    }
}

﻿
namespace Ticket_Management_System
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSide = new System.Windows.Forms.Panel();
            this.btnWeeklyReport = new System.Windows.Forms.Button();
            this.btnTicketEntry = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.lbSeparator = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlSide.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSide
            // 
            this.pnlSide.BackColor = System.Drawing.Color.Black;
            this.pnlSide.Controls.Add(this.btnWeeklyReport);
            this.pnlSide.Controls.Add(this.btnTicketEntry);
            this.pnlSide.Controls.Add(this.btnReport);
            this.pnlSide.Controls.Add(this.btnDashboard);
            this.pnlSide.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSide.Location = new System.Drawing.Point(0, 0);
            this.pnlSide.Name = "pnlSide";
            this.pnlSide.Size = new System.Drawing.Size(1000, 71);
            this.pnlSide.TabIndex = 0;
            // 
            // btnWeeklyReport
            // 
            this.btnWeeklyReport.BackColor = System.Drawing.Color.Black;
            this.btnWeeklyReport.FlatAppearance.BorderSize = 0;
            this.btnWeeklyReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWeeklyReport.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWeeklyReport.ForeColor = System.Drawing.Color.White;
            this.btnWeeklyReport.Location = new System.Drawing.Point(624, 12);
            this.btnWeeklyReport.Name = "btnWeeklyReport";
            this.btnWeeklyReport.Size = new System.Drawing.Size(283, 51);
            this.btnWeeklyReport.TabIndex = 4;
            this.btnWeeklyReport.Text = "WEEKLY REPORT CHART";
            this.btnWeeklyReport.UseVisualStyleBackColor = false;
            this.btnWeeklyReport.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // btnTicketEntry
            // 
            this.btnTicketEntry.BackColor = System.Drawing.Color.Black;
            this.btnTicketEntry.FlatAppearance.BorderSize = 0;
            this.btnTicketEntry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTicketEntry.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTicketEntry.ForeColor = System.Drawing.Color.White;
            this.btnTicketEntry.Location = new System.Drawing.Point(207, 12);
            this.btnTicketEntry.Name = "btnTicketEntry";
            this.btnTicketEntry.Size = new System.Drawing.Size(189, 51);
            this.btnTicketEntry.TabIndex = 0;
            this.btnTicketEntry.Text = "TICKET ENTRY";
            this.btnTicketEntry.UseVisualStyleBackColor = false;
            this.btnTicketEntry.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.Black;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.Location = new System.Drawing.Point(12, 14);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(189, 51);
            this.btnDashboard.TabIndex = 3;
            this.btnDashboard.Text = "DASHBOARD";
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackColor = System.Drawing.Color.Black;
            this.btnReport.FlatAppearance.BorderSize = 0;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.ForeColor = System.Drawing.Color.White;
            this.btnReport.Location = new System.Drawing.Point(429, 12);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(189, 51);
            this.btnReport.TabIndex = 2;
            this.btnReport.Text = "REPORT";
            this.btnReport.UseVisualStyleBackColor = false;
            this.btnReport.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbSeparator
            // 
            this.lbSeparator.AutoSize = true;
            this.lbSeparator.ForeColor = System.Drawing.Color.LightGray;
            this.lbSeparator.Location = new System.Drawing.Point(-3, -18);
            this.lbSeparator.Name = "lbSeparator";
            this.lbSeparator.Size = new System.Drawing.Size(810, 20);
            this.lbSeparator.TabIndex = 6;
            this.lbSeparator.Text = "_________________________________________________________________________________" +
    "________";
            // 
            // pnlMain
            // 
            this.pnlMain.AutoScroll = true;
            this.pnlMain.BackColor = System.Drawing.Color.GhostWhite;
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 71);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1000, 623);
            this.pnlMain.TabIndex = 7;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1000, 694);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.lbSeparator);
            this.Controls.Add(this.pnlSide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.dashboard_FormClosing);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.pnlSide.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSide;
        private System.Windows.Forms.Button btnTicketEntry;
        private System.Windows.Forms.Button btnWeeklyReport;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label lbSeparator;
        private System.Windows.Forms.Panel pnlMain;
    }
}
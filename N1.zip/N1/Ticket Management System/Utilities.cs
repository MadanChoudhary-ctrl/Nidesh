﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Management_System
{
    class Utilities
    {
        public static void Export()
        {
            Person obj = new Person();
            List<Person> customerList = obj.List();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("ID,Name,Address,Phone,Category,TotalPeople,InTime,OutTime,TotalTime,Rate,Date,Day");
            foreach (var customer in customerList)
            {
                sb.AppendLine(customer.Id.ToString() + "," + customer.Name.ToString() + "," + customer.Address.ToString() + "," +
                              customer.Phone.ToString() + "," + customer.Category.ToString() + "," + customer.TotalPeople.ToString() + "," +
                              customer.InTime.ToString() + "," + customer.OutTime.ToString() + "," + customer.TotalTime.ToString() + "," +
                              customer.Rate.ToString() + "," + customer.VisitDate.ToString() + "," + customer.VisitDay.ToString());
            }
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "Save an CSV File";
            sfd.Filter = "CSV|*.csv|All file|*.*";
            sfd.FilterIndex = 1;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(sfd.FileName, sb.ToString());
                MessageBox.Show("File saved successfully");
            }
        }
        public static void WriteToTextFile(string path, string data, bool append = true, int count = 1)
        {
            if (!File.Exists(path))
            {
                var file = File.Create(path);
                file.Close();
            }
            using (StreamWriter writer = new StreamWriter(path, append: append))
            {
                if (!append)
                {
                    //remove opening bracket "[" from data passed
                    data = data.Trim().Substring(1, data.Trim().Length - 1);
                    //remove last bracket "]" from data passed
                    data = data.Trim().Substring(0, data.Trim().Length - 1);
                }
                if (count != 0)
                {
                    data = data + ",";
                }
                writer.WriteLine(data);
            }
        }
        public static string ReadFromTextFile(string path)
        {
            if (File.Exists(path))
            {
                string data;
                using (StreamReader r = new StreamReader(path))
                {
                    data = r.ReadToEnd();

                }
                if (data != "")
                {
                    data = "[" + data + "]";
                }
                return data;
            }
            return null;
        }
        public static DataTable ConvertToDataTable<DT>(IList<DT> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(DT));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            if (data != null)
            {
                foreach (DT item in data)
                {
                    DataRow row = table.NewRow();
                    foreach (PropertyDescriptor prop in properties)
                        row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                    table.Rows.Add(row);
                }
            }
            return table;
        }
    }
}
